{
    "sProcessing":   "მიმდინარეობს დამუშავება...",
    "sLengthMenu":   "აჩვენე _MENU_ ჩანაწერი",
    "sZeroRecords":  "არაფერი მოიძებნა",
    "sInfo":         "ნაჩვენებია ჩანაწერები _START_–დან _END_–მდე, სულ _TOTAL_ ჩანაწერია",
    "sInfoEmpty":    "ნაჩვენებია ჩანაწერები 0–დან 0–მდე, სულ 0 ჩანაწერია",
    "sInfoFiltered": "(გაფილტრული შედეგი _MAX_ ჩანაწერიდან)",
    "sInfoPostFix":  "",
    "sSearch":       "ძიება:",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "პირველი",
        "sPrevious": "წინა",
        "sNext":     "შემდეგი",
        "sLast":     "ბოლო"
}
