<script type="text/javascript">
    if(typeof wpDataTablesCharts == 'undefined'){
        var wpDataTablesCharts = [];
    }
    wpDataTablesCharts['<?php echo $tableId?>'] = <?php echo $chartProperties ?>;
</script>