<div class="">

<?php echo $wdt_output_table ?>

</div>